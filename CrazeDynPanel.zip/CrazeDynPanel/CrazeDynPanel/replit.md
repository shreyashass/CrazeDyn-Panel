# CrazeDyn Panel - Minecraft Server Manager

## Overview

CrazeDyn Panel is a complete Windows desktop application for managing Minecraft servers locally with a modern PyQt6 GUI. The application provides an all-in-one solution for creating, configuring, and running Minecraft servers using PaperMC builds with automatic version fetching, Playit.gg plugin integration, and comprehensive system monitoring capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Architecture
The application follows a modular architecture with clear separation of concerns:

**Server Management Layer**: The `ServerManager` class handles the complete lifecycle of Minecraft server instances, including creation, startup/shutdown, and monitoring. Each server is represented by a `MinecraftServer` class that encapsulates server configuration, process management, and runtime statistics.

**Download Management**: The `PaperMCDownloader` class manages dynamic fetching of PaperMC server versions from JSON feeds and handles automatic downloading of server JAR files and plugins. It includes caching mechanisms and fallback version lists for reliability.

**System Monitoring**: The `SystemMonitor` class provides real-time tracking of CPU, RAM, and network usage for both system-wide and per-process monitoring. It uses a callback-based architecture for efficient GUI updates.

**Network Management**: Simple network configuration focused on Playit.gg tunnel integration for easy server accessibility without port forwarding requirements.

### GUI Framework
Built on PyQt6 with a modern dark theme and neon accent design:

**Main Window**: Tabbed interface providing server dashboard, creation wizard, and system monitoring views. Uses custom-styled widgets like `ModernButton` for consistent visual design.

**Server Cards**: Individual server management widgets displaying status indicators, control buttons, and real-time statistics in a card-based layout. Each server card includes a "Manage" button to open detailed server management windows.

**Detailed Server Management**: Comprehensive server management interface with tabbed sections for:
- Console: Server-specific console with real-time output and command input
- Content Browser: File system browser for server directories with upload/download capabilities
- Configuration: Direct editor for server.properties and other config files
- Plugins: Plugin management with installation, removal, and status monitoring
- Server Info: Detailed server statistics, resource usage, and system information

**Console Integration**: Real-time server console viewing with log streaming capabilities and command input functionality available both globally and per-server.

**Animation System**: Smooth transitions and hover effects using QPropertyAnimation for enhanced user experience.

### Process Management
Servers run as detached background processes allowing the GUI to be closed while keeping servers active. The application tracks server PIDs and can reconnect to running instances on restart.

### Data Persistence
Server configurations are stored in JSON format (`servers.json`) with automatic backup and recovery mechanisms. The application maintains version caches and user preferences persistently.

### Build System
Multi-target build system supporting:
- Single executable creation via PyInstaller
- Portable distribution packaging
- Automatic dependency resolution and Java installation
- Comprehensive test suite integration

## External Dependencies

**Core Dependencies**:
- PyQt6 - Modern GUI framework for the desktop interface
- psutil - System and process monitoring capabilities
- requests - HTTP client for PaperMC API and file downloads

**Runtime Requirements**:
- Java Runtime Environment - Required for Minecraft server execution
- Windows 10/11 - Target platform with specific system integration features

**Third-Party Services**:
- PaperMC API - Dynamic server version fetching and JAR downloads
- Playit.gg Plugin - Automatic tunnel plugin integration for server accessibility
- UPnP Services - Automatic port forwarding and network configuration

**Build Tools**:
- PyInstaller - Single executable creation for distribution
- Windows SDK components - For proper Windows integration and theming

**Optional Integrations**:
- miniupnpc - UPnP port mapping functionality (optional dependency)
- Windows Firewall APIs - Automatic firewall rule management