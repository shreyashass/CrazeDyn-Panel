#!/bin/bash

echo "================================================"
echo "    CrazeDyn Panel - Linux Setup Script"
echo "    Minecraft Server Manager Installation"
echo "================================================"
echo

# Check if running as root for system packages
if [[ $EUID -eq 0 ]]; then
   echo "Note: Running as root - can install system packages"
   CAN_INSTALL_SYSTEM=true
else
   echo "Note: Not running as root - will skip system package installation"
   echo "You may need to install system packages manually if needed"
   CAN_INSTALL_SYSTEM=false
fi

echo
echo "[1/6] Checking system requirements..."
echo

# Check Linux distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "Operating System: $NAME $VERSION"
else
    echo "Cannot determine Linux distribution"
fi

# Check architecture
echo "Architecture: $(uname -m)"

echo
echo "[2/6] Installing Python 3.11..."
echo

# Check if Python 3.11+ is available
if command -v python3.11 &> /dev/null; then
    echo "Python 3.11 found: $(python3.11 --version)"
    PYTHON_CMD="python3.11"
elif command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1-2)
    echo "Python 3 found: $(python3 --version)"
    if (( $(echo "$PYTHON_VERSION >= 3.8" | bc -l) )); then
        echo "Python version is compatible"
        PYTHON_CMD="python3"
    else
        echo "ERROR: Python 3.8+ is required"
        exit 1
    fi
else
    echo "ERROR: Python 3 not found"
    echo "Please install Python 3.8+ first"
    
    if [ "$CAN_INSTALL_SYSTEM" = true ]; then
        echo "Attempting to install Python 3..."
        
        # Detect package manager and install Python
        if command -v apt-get &> /dev/null; then
            apt-get update
            apt-get install -y python3 python3-pip python3-venv
        elif command -v yum &> /dev/null; then
            yum install -y python3 python3-pip
        elif command -v dnf &> /dev/null; then
            dnf install -y python3 python3-pip
        elif command -v pacman &> /dev/null; then
            pacman -S --noconfirm python python-pip
        else
            echo "Package manager not detected. Please install Python 3 manually."
            exit 1
        fi
        
        PYTHON_CMD="python3"
    else
        exit 1
    fi
fi

echo
echo "[3/6] Installing Java 17..."
echo

# Check if Java is installed
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
    echo "Java found: $(java -version 2>&1 | head -n 1)"
    
    if [ "$JAVA_VERSION" -ge 17 ] 2>/dev/null; then
        echo "Java version is compatible (17+)"
    else
        echo "WARNING: Java 17+ is recommended for best performance"
    fi
else
    echo "Java not found. Installing OpenJDK 17..."
    
    if [ "$CAN_INSTALL_SYSTEM" = true ]; then
        # Install Java based on distribution
        if command -v apt-get &> /dev/null; then
            apt-get update
            apt-get install -y openjdk-17-jdk
        elif command -v yum &> /dev/null; then
            yum install -y java-17-openjdk java-17-openjdk-devel
        elif command -v dnf &> /dev/null; then
            dnf install -y java-17-openjdk java-17-openjdk-devel
        elif command -v pacman &> /dev/null; then
            pacman -S --noconfirm jdk17-openjdk
        else
            echo "Please install Java 17+ manually"
        fi
    else
        echo "Please install Java 17+ manually or run script as root"
    fi
fi

echo
echo "[4/6] Installing system dependencies..."
echo

if [ "$CAN_INSTALL_SYSTEM" = true ]; then
    echo "Installing GUI and system libraries..."
    
    # Install system dependencies based on distribution
    if command -v apt-get &> /dev/null; then
        apt-get install -y \
            python3-pyqt6 \
            libfontconfig1 \
            libfreetype6 \
            libx11-6 \
            libxrender1 \
            libdbus-1-3 \
            libzstd1 \
            build-essential \
            python3-dev \
            libminiupnpc-dev
    elif command -v yum &> /dev/null; then
        yum install -y \
            python3-qt6 \
            fontconfig \
            freetype \
            libX11 \
            libXrender \
            dbus-libs \
            libzstd \
            gcc \
            python3-devel \
            miniupnpc-devel
    elif command -v dnf &> /dev/null; then
        dnf install -y \
            python3-qt6 \
            fontconfig \
            freetype \
            libX11 \
            libXrender \
            dbus-libs \
            libzstd \
            gcc \
            python3-devel \
            miniupnpc-devel
    elif command -v pacman &> /dev/null; then
        pacman -S --noconfirm \
            python-pyqt6 \
            fontconfig \
            freetype2 \
            libx11 \
            libxrender \
            dbus \
            zstd \
            base-devel \
            miniupnpc
    fi
else
    echo "Skipping system package installation (not running as root)"
fi

echo
echo "[5/6] Installing Python dependencies..."
echo

# Create virtual environment (optional but recommended)
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    $PYTHON_CMD -m venv venv
fi

# Activate virtual environment
source venv/bin/activate 2>/dev/null || echo "Using system Python"

# Upgrade pip
$PYTHON_CMD -m pip install --upgrade pip

# Install required packages
echo "Installing PyQt6..."
$PYTHON_CMD -m pip install PyQt6

echo "Installing system monitoring tools..."
$PYTHON_CMD -m pip install psutil

echo "Installing network tools..."
$PYTHON_CMD -m pip install requests

echo "Installing build tools..."
$PYTHON_CMD -m pip install pyinstaller

echo "Installing UPnP support..."
$PYTHON_CMD -m pip install miniupnpc

echo
echo "[6/6] Setting up firewall rules..."
echo

if [ "$CAN_INSTALL_SYSTEM" = true ]; then
    echo "Configuring firewall for Minecraft servers..."
    
    # Configure firewall based on what's available
    if command -v ufw &> /dev/null; then
        # Ubuntu/Debian UFW
        ufw allow 25565:25575/tcp comment "Minecraft Servers"
        ufw allow 25565:25575/udp comment "Minecraft Servers"
        ufw allow 2000:2100/tcp comment "Playit.gg Tunnels"
        ufw allow 2000:2100/udp comment "Playit.gg Tunnels"
        echo "UFW firewall rules added"
    elif command -v firewall-cmd &> /dev/null; then
        # CentOS/RHEL/Fedora firewalld
        firewall-cmd --permanent --add-port=25565-25575/tcp
        firewall-cmd --permanent --add-port=25565-25575/udp
        firewall-cmd --permanent --add-port=2000-2100/tcp
        firewall-cmd --permanent --add-port=2000-2100/udp
        firewall-cmd --reload
        echo "Firewalld rules added"
    elif command -v iptables &> /dev/null; then
        # Generic iptables
        iptables -A INPUT -p tcp --dport 25565:25575 -j ACCEPT
        iptables -A INPUT -p udp --dport 25565:25575 -j ACCEPT
        iptables -A INPUT -p tcp --dport 2000:2100 -j ACCEPT
        iptables -A INPUT -p udp --dport 2000:2100 -j ACCEPT
        echo "Iptables rules added (consider making them persistent)"
    else
        echo "No supported firewall found. Please configure manually if needed."
    fi
else
    echo "Skipping firewall configuration (not running as root)"
fi

echo
echo "================================================"
echo "           INSTALLATION COMPLETED!"
echo "================================================"
echo
echo "Setup Summary:"
echo "✓ Python 3.8+ confirmed"
echo "✓ Java 17+ confirmed"
echo "✓ PyQt6 GUI framework installed"
echo "✓ System monitoring tools installed"
echo "✓ Network and UPnP tools installed"
echo "✓ System dependencies installed"
if [ "$CAN_INSTALL_SYSTEM" = true ]; then
    echo "✓ Firewall configured"
else
    echo "⚠ Firewall not configured (needs root)"
fi
echo
echo "You can now run CrazeDyn Panel by:"
echo "1. cd $(pwd)"
if [ -d "venv" ]; then
    echo "2. source venv/bin/activate"
    echo "3. python Main/app/__main__.py"
else
    echo "2. $PYTHON_CMD Main/app/__main__.py"
fi
echo
echo "Or create a desktop launcher with the command above."
echo

# Ask if user wants to run the application now
read -p "Would you like to launch the application now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Launching CrazeDyn Panel..."
    cd "$(dirname "$0")"
    if [ -d "venv" ]; then
        source venv/bin/activate
    fi
    $PYTHON_CMD Main/app/__main__.py
fi