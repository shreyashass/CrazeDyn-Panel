import unittest
import tempfile
import shutil
import json
from pathlib import Path
import sys
import os

# Add app directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.server_manager import ServerManager, MinecraftServer

class TestMinecraftServer(unittest.TestCase):
    """Test MinecraftServer class"""
    
    def test_server_creation(self):
        """Test server object creation"""
        server = MinecraftServer(
            name="TestServer",
            path="/test/path",
            jar="paper-1.21.8-39.jar",
            min_ram="2G",
            max_ram="4G",
            port=25565
        )
        
        self.assertEqual(server.name, "TestServer")
        self.assertEqual(server.jar, "paper-1.21.8-39.jar")
        self.assertEqual(server.min_ram, "2G")
        self.assertEqual(server.max_ram, "4G")
        self.assertEqual(server.port, 25565)
        self.assertEqual(server.status, "stopped")
        
    def test_server_serialization(self):
        """Test server to/from dict conversion"""
        server = MinecraftServer(
            name="TestServer",
            path="/test/path", 
            jar="paper-1.21.8-39.jar",
            min_ram="2G",
            max_ram="4G"
        )
        
        # Test to_dict
        data = server.to_dict()
        self.assertIsInstance(data, dict)
        self.assertEqual(data["name"], "TestServer")
        self.assertEqual(data["jar"], "paper-1.21.8-39.jar")
        
        # Test from_dict
        new_server = MinecraftServer.from_dict(data)
        self.assertEqual(new_server.name, server.name)
        self.assertEqual(new_server.jar, server.jar)
        self.assertEqual(new_server.min_ram, server.min_ram)

class TestServerManager(unittest.TestCase):
    """Test ServerManager class"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_dir = tempfile.mkdtemp()
        self.servers_file = Path(self.temp_dir) / "test_servers.json"
        self.manager = ServerManager(str(self.servers_file))
        
    def tearDown(self):
        """Clean up test environment"""
        self.manager.stop_monitoring()
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        
    def test_manager_initialization(self):
        """Test ServerManager initialization"""
        self.assertIsInstance(self.manager.servers, dict)
        self.assertEqual(len(self.manager.servers), 0)
        
    def test_server_creation(self):
        """Test server creation"""
        success = self.manager.create_server(
            name="TestServer",
            version="1.21.8",
            min_ram="2G",
            max_ram="4G",
            storage_path=self.temp_dir,
            port=25565
        )
        
        self.assertTrue(success)
        self.assertIn("TestServer", self.manager.servers)
        
        server = self.manager.servers["TestServer"]
        self.assertEqual(server.name, "TestServer")
        self.assertEqual(server.min_ram, "2G")
        self.assertEqual(server.max_ram, "4G")
        
        # Check if server directory was created
        server_path = Path(server.path)
        self.assertTrue(server_path.exists())
        self.assertTrue((server_path / "start.bat").exists())
        self.assertTrue((server_path / "server.properties").exists())
        self.assertTrue((server_path / "eula.txt").exists())
        
    def test_server_persistence(self):
        """Test server saving and loading"""
        # Create a server
        self.manager.create_server(
            name="PersistTest",
            version="1.21.8",
            min_ram="1G",
            max_ram="2G",
            storage_path=self.temp_dir
        )
        
        # Save servers
        self.manager.save_servers()
        self.assertTrue(self.servers_file.exists())
        
        # Create new manager and load
        new_manager = ServerManager(str(self.servers_file))
        self.assertIn("PersistTest", new_manager.servers)
        
        server = new_manager.servers["PersistTest"]
        self.assertEqual(server.name, "PersistTest")
        self.assertEqual(server.min_ram, "1G")
        
    def test_duplicate_server_creation(self):
        """Test that duplicate server names are handled"""
        # Create first server
        success1 = self.manager.create_server(
            name="DupeTest",
            version="1.21.8",
            min_ram="2G",
            max_ram="4G",
            storage_path=self.temp_dir
        )
        self.assertTrue(success1)
        
        # Try to create server with same name
        success2 = self.manager.create_server(
            name="DupeTest",
            version="1.20.6", 
            min_ram="1G",
            max_ram="2G",
            storage_path=self.temp_dir
        )
        # Should fail or handle gracefully
        # Implementation may vary - either return False or create with different name
        
    def test_server_deletion(self):
        """Test server deletion"""
        # Create server
        self.manager.create_server(
            name="DeleteTest",
            version="1.21.8",
            min_ram="2G",
            max_ram="4G",
            storage_path=self.temp_dir
        )
        
        self.assertIn("DeleteTest", self.manager.servers)
        
        # Delete server
        success = self.manager.delete_server("DeleteTest")
        self.assertTrue(success)
        self.assertNotIn("DeleteTest", self.manager.servers)
        
    def test_server_status_tracking(self):
        """Test server status management"""
        # Create server
        self.manager.create_server(
            name="StatusTest",
            version="1.21.8",
            min_ram="2G",
            max_ram="4G",
            storage_path=self.temp_dir
        )
        
        # Initial status should be stopped
        status = self.manager.get_server_status("StatusTest")
        self.assertEqual(status, "stopped")
        
        # Test non-existent server
        status = self.manager.get_server_status("NonExistent")
        self.assertEqual(status, "unknown")

class TestBatchFileGeneration(unittest.TestCase):
    """Test batch file generation"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        
    def test_start_batch_creation(self):
        """Test start.bat file creation"""
        server = MinecraftServer(
            name="BatchTest",
            path=self.temp_dir,
            jar="paper-1.21.8-39.jar",
            min_ram="2G",
            max_ram="4G"
        )
        
        manager = ServerManager()
        manager._create_start_batch(server)
        
        batch_file = Path(self.temp_dir) / "start.bat"
        self.assertTrue(batch_file.exists())
        
        # Check batch file content
        content = batch_file.read_text()
        self.assertIn("java -Xms2G -Xmx4G", content)
        self.assertIn("paper-1.21.8-39.jar", content)
        self.assertIn("nogui", content)
        
    def test_server_properties_creation(self):
        """Test server.properties file creation"""
        server = MinecraftServer(
            name="PropsTest",
            path=self.temp_dir,
            jar="paper-1.21.8-39.jar",
            min_ram="2G",
            max_ram="4G",
            port=25566
        )
        
        manager = ServerManager()
        manager._create_server_properties(server)
        
        props_file = Path(self.temp_dir) / "server.properties"
        self.assertTrue(props_file.exists())
        
        # Check properties content
        content = props_file.read_text()
        self.assertIn("server-port=25566", content)
        self.assertIn("PropsTest", content)

if __name__ == "__main__":
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add all test cases
    suite.addTest(unittest.makeSuite(TestMinecraftServer))
    suite.addTest(unittest.makeSuite(TestServerManager))
    suite.addTest(unittest.makeSuite(TestBatchFileGeneration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print(f"\nTests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.failures:
        print("\nFailures:")
        for test, failure in result.failures:
            print(f"- {test}: {failure}")
            
    if result.errors:
        print("\nErrors:")
        for test, error in result.errors:
            print(f"- {test}: {error}")
    
    # Exit with error code if tests failed
    exit_code = len(result.failures) + len(result.errors)
    sys.exit(exit_code)