import json
import os
import subprocess
import psutil
import time
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

class MinecraftServer:
    """Represents a single Minecraft server instance"""
    
    def __init__(self, name: str, path: str, jar: str, min_ram: str, max_ram: str, port: int = 25565, storage_limit: int = 10):
        self.name = name
        self.path = Path(path)
        self.jar = jar
        self.min_ram = min_ram
        self.max_ram = max_ram
        self.port = port
        self.storage_limit = storage_limit  # Storage limit in GB
        self.process: Optional[subprocess.Popen] = None
        self.pid: Optional[int] = None
        self.status = "stopped"
        self.console_lines = []
        self.cpu_usage = 0.0
        self.ram_usage = 0.0
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert server to dictionary for JSON serialization"""
        return {
            "name": self.name,
            "path": str(self.path),
            "jar": self.jar,
            "min_ram": self.min_ram,
            "max_ram": self.max_ram,
            "port": self.port,
            "storage_limit": self.storage_limit,
            "pid": self.pid,
            "status": self.status
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MinecraftServer':
        """Create server from dictionary"""
        server = cls(
            name=data["name"],
            path=data["path"],
            jar=data["jar"],
            min_ram=data["min_ram"],
            max_ram=data["max_ram"],
            port=data.get("port", 25565),
            storage_limit=data.get("storage_limit", 10)
        )
        server.pid = data.get("pid")
        server.status = data.get("status", "stopped")
        return server

class ServerManager:
    """Manages all Minecraft servers"""
    
    def __init__(self, servers_file: str = "servers.json"):
        self.servers_file = Path(servers_file)
        self.servers: Dict[str, MinecraftServer] = {}
        self.monitoring_thread = None
        self.monitoring_active = False
        self.load_servers()
        
    def load_servers(self):
        """Load servers from JSON file"""
        # Try primary location first
        if self.servers_file.exists():
            try:
                with open(self.servers_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for server_data in data:
                        server = MinecraftServer.from_dict(server_data)
                        self.servers[server.name] = server
                        # Check if server is still running
                        if server.pid and self.is_process_running(server.pid):
                            server.status = "running"
                            server.process = psutil.Process(server.pid)
                        else:
                            server.status = "stopped"
                            server.pid = None
                return
            except Exception as e:
                print(f"Error loading servers from {self.servers_file}: {e}")
        
        # Try fallback location
        fallback_path = Path("servers.json")
        if fallback_path.exists():
            try:
                with open(fallback_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for server_data in data:
                        server = MinecraftServer.from_dict(server_data)
                        self.servers[server.name] = server
                        # Check if server is still running
                        if server.pid and self.is_process_running(server.pid):
                            server.status = "running"
                            server.process = psutil.Process(server.pid)
                        else:
                            server.status = "stopped"
                            server.pid = None
                print(f"Loaded servers from fallback location: {fallback_path.absolute()}")
                return
            except Exception as e:
                print(f"Error loading servers from fallback {fallback_path}: {e}")
        
        # Initialize empty if no file found
        self.servers = {}
    
    def save_servers(self):
        """Save servers to JSON file"""
        try:
            # Ensure the directory exists
            self.servers_file.parent.mkdir(exist_ok=True)
            
            data = [server.to_dict() for server in self.servers.values()]
            with open(self.servers_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving servers: {e}")
            # Try to create the file in current directory as fallback
            try:
                fallback_path = Path("servers.json")
                with open(fallback_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                print(f"Saved servers to fallback location: {fallback_path.absolute()}")
            except Exception as e2:
                print(f"Fallback save also failed: {e2}")
    
    def create_server(self, name: str, version: str, min_ram: str, max_ram: str, 
                     storage_path: str, port: int = 25565, storage_limit: int = 10) -> bool:
        """Create a new Minecraft server"""
        try:
            server_path = Path(storage_path) / name
            server_path.mkdir(parents=True, exist_ok=True)
            
            # Create plugins directory
            plugins_path = server_path / "plugins"
            plugins_path.mkdir(exist_ok=True)
            
            # Create logs directory
            logs_path = server_path / "logs"
            logs_path.mkdir(exist_ok=True)
            
            # Determine jar filename from version
            jar_name = f"paper-{version}.jar"
            
            # Create server instance
            server = MinecraftServer(
                name=name,
                path=str(server_path),
                jar=jar_name,
                min_ram=min_ram,
                max_ram=max_ram,
                port=port,
                storage_limit=storage_limit
            )
            
            # Create start.bat file
            self._create_start_batch(server)
            
            # Create server.properties with custom port
            self._create_server_properties(server)
            
            # Accept EULA
            self._create_eula_file(server)
            
            self.servers[name] = server
            self.save_servers()
            return True
            
        except Exception as e:
            print(f"Error creating server: {e}")
            return False
    
    def _create_start_batch(self, server: MinecraftServer):
        """Create start.bat file for the server"""
        batch_content = f"""@echo off
title {server.name} - Minecraft Server
echo Starting {server.name}...
echo.
java -Xms{server.min_ram} -Xmx{server.max_ram} -jar {server.jar} nogui
echo.
echo Server stopped. Press any key to close...
pause
"""
        batch_path = Path(server.path) / "start.bat"
        with open(batch_path, 'w') as f:
            f.write(batch_content)
    
    def _create_server_properties(self, server: MinecraftServer):
        """Create server.properties file with custom port and external access support"""
        properties_content = f"""# Minecraft server properties
# Generated by CrazeDyn Panel - {time.strftime('%Y-%m-%d %H:%M:%S')}
server-port={server.port}
gamemode=survival
difficulty=easy
spawn-protection=16
max-players=20
level-name=world
level-type=minecraft:normal
enable-command-block=true
online-mode=true
pvp=true
white-list=false
allow-nether=true
generate-structures=true
enforce-whitelist=false
enable-query=true
enable-rcon=false
motd=§6{server.name} §f- §bPowered by CrazeDyn Panel
"""
        properties_path = Path(server.path) / "server.properties"
        with open(properties_path, 'w', encoding='utf-8') as f:
            f.write(properties_content)
    
    def _create_eula_file(self, server: MinecraftServer):
        """Create eula.txt file (automatically accept EULA)"""
        eula_content = """# By running the server you are agreeing to the Minecraft EULA
# https://account.mojang.com/documents/minecraft_eula
eula=true
"""
        eula_path = Path(server.path) / "eula.txt"
        with open(eula_path, 'w') as f:
            f.write(eula_content)
    
    def start_server(self, name: str) -> bool:
        """Start a Minecraft server"""
        if name not in self.servers:
            return False
            
        server = self.servers[name]
        if server.status == "running":
            return True
            
        try:
            # Change to server directory
            os.chdir(server.path)
            
            # Start the server process
            cmd = f'java -Xms{server.min_ram} -Xmx{server.max_ram} -jar {server.jar} nogui'
            
            # Start process in background
            server.process = subprocess.Popen(
                cmd,
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True,
                cwd=server.path
            )
            
            server.pid = server.process.pid
            server.status = "starting"
            
            # Wait a moment for process to fully start
            time.sleep(0.5)
            
            # Check if process is actually running and update status
            if self.is_process_running(server.pid):
                server.status = "running"
            else:
                server.status = "stopped"
            
            # Start monitoring thread for this server
            monitor_thread = threading.Thread(
                target=self._monitor_server_output,
                args=(server,),
                daemon=True
            )
            monitor_thread.start()
            
            self.save_servers()
            return True
            
        except Exception as e:
            print(f"Error starting server {name}: {e}")
            server.status = "stopped"
            return False
    
    def stop_server(self, name: str) -> bool:
        """Stop a Minecraft server gracefully"""
        if name not in self.servers:
            return False
            
        server = self.servers[name]
        if server.status == "stopped":
            return True
            
        try:
            if server.process and server.process.poll() is None:
                # Send stop command to server
                server.process.stdin.write("stop\n")
                server.process.stdin.flush()
                
                # Wait for graceful shutdown
                try:
                    server.process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    # Force kill if not responding
                    server.process.kill()
                    server.process.wait()
            
            server.status = "stopped"
            server.pid = None
            server.process = None
            self.save_servers()
            return True
            
        except Exception as e:
            print(f"Error stopping server {name}: {e}")
            return False
    
    def restart_server(self, name: str) -> bool:
        """Restart a Minecraft server"""
        if self.stop_server(name):
            time.sleep(2)  # Brief pause
            return self.start_server(name)
        return False
    
    def delete_server(self, name: str) -> bool:
        """Delete a Minecraft server (removes from management, not files)"""
        if name in self.servers:
            # Stop server first if running
            self.stop_server(name)
            del self.servers[name]
            self.save_servers()
            return True
        return False
    
    def get_server_status(self, name: str) -> str:
        """Get current status of a server"""
        if name in self.servers:
            server = self.servers[name]
            if server.pid and self.is_process_running(server.pid):
                return "running"
            else:
                return "stopped"
        return "unknown"
    
    def get_server_stats(self, name: str) -> Dict[str, float]:
        """Get CPU and RAM usage for a server"""
        stats = {"cpu": 0.0, "ram": 0.0, "ram_mb": 0.0}
        
        if name in self.servers:
            server = self.servers[name]
            if server.process and server.status == "running":
                try:
                    # Use psutil.Process for monitoring stats
                    psutil_process = psutil.Process(server.pid)
                    stats["cpu"] = psutil_process.cpu_percent()
                    memory_info = psutil_process.memory_info()
                    stats["ram_mb"] = memory_info.rss / 1024 / 1024  # MB
                    stats["ram"] = (memory_info.rss / psutil.virtual_memory().total) * 100
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                    
        return stats
    
    def _monitor_server_output(self, server: MinecraftServer):
        """Monitor server console output in a separate thread"""
        if not server.process:
            return
            
        try:
            while server.process and server.process.poll() is None:
                line = server.process.stdout.readline()
                if line:
                    # Decode the line properly to handle any encoding issues
                    if isinstance(line, bytes):
                        try:
                            line = line.decode('utf-8', errors='replace')
                        except:
                            line = line.decode('latin-1', errors='replace')
                    
                    # Clean the line but preserve meaningful content
                    line = line.rstrip('\n\r').strip()
                    
                    if line:  # Only append non-empty lines
                        formatted_line = f"[{time.strftime('%H:%M:%S')}] {line}"
                        server.console_lines.append(formatted_line)
                        
                        # Keep only last 1000 lines
                        if len(server.console_lines) > 1000:
                            server.console_lines = server.console_lines[-1000:]
                        
                        # Update status based on output
                        if "Done (" in line and "For help, type" in line:
                            server.status = "running"
                            self.save_servers()
                        
        except Exception as e:
            print(f"Error monitoring server output: {e}")
        finally:
            if server.status != "stopped":
                server.status = "stopped"
                server.pid = None
                self.save_servers()
    
    def send_command(self, name: str, command: str) -> bool:
        """Send a command to a running server"""
        if name in self.servers:
            server = self.servers[name]
            if server.process and server.process.poll() is None:
                try:
                    server.process.stdin.write(f"{command}\n")
                    server.process.stdin.flush()
                    return True
                except Exception as e:
                    print(f"Error sending command: {e}")
        return False
    
    def get_console_output(self, name: str, lines: int = 50) -> List[str]:
        """Get recent console output for a server"""
        if name in self.servers:
            server = self.servers[name]
            return server.console_lines[-lines:] if server.console_lines else []
        return []
    
    @staticmethod
    def is_process_running(pid: int) -> bool:
        """Check if a process with given PID is running"""
        try:
            return psutil.pid_exists(pid)
        except:
            return False
    
    def start_monitoring(self):
        """Start the monitoring thread for all servers"""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._monitor_all_servers, daemon=True)
            self.monitoring_thread.start()
    
    def stop_monitoring(self):
        """Stop the monitoring thread"""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=1)
    
    def _monitor_all_servers(self):
        """Monitor all servers in a loop"""
        while self.monitoring_active:
            for server in self.servers.values():
                if server.status == "running" and server.process:
                    try:
                        # Update CPU and RAM usage using psutil
                        psutil_process = psutil.Process(server.pid)
                        server.cpu_usage = psutil_process.cpu_percent()
                        memory_info = psutil_process.memory_info()
                        server.ram_usage = memory_info.rss / 1024 / 1024  # MB
                        
                        # Check if process is still alive
                        if server.process and server.process.poll() is not None:
                            server.status = "stopped"
                            server.pid = None
                            server.process = None
                            
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        server.status = "stopped"
                        server.pid = None
                        server.process = None
            
            time.sleep(1)  # Update every second