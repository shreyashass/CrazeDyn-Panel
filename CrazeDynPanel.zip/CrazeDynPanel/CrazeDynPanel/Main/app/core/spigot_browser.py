"""
SpigotMC Resources Browser - Plugin discovery and download functionality
"""

import requests
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import re


@dataclass
class PluginInfo:
    """Information about a SpigotMC plugin"""
    id: str
    name: str
    tag: str
    author: str
    description: str
    version: str
    downloads: int
    rating: float
    price: float
    category: str
    size: str
    updated: str
    icon_url: str
    download_url: str
    premium: bool


class SpigotBrowser:
    """Browser for SpigotMC Resources with plugin discovery and download"""
    
    BASE_URL = "https://api.spiget.org/v2"
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'CrazeDyn-Panel/1.0 (Minecraft Server Manager)'
        })
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
    
    def search_plugins(self, query: str, category: str = None, sort: str = "downloads", 
                      size: int = 20, page: int = 1) -> Tuple[List[PluginInfo], int]:
        """
        Search for plugins on SpigotMC
        
        Args:
            query: Search term
            category: Category filter
            sort: Sort method (downloads, rating, name, updated)
            size: Results per page
            page: Page number
            
        Returns:
            Tuple of (plugin_list, total_pages)
        """
        try:
            cache_key = f"search_{query}_{category}_{sort}_{size}_{page}"
            
            # Check cache
            if cache_key in self.cache:
                cached_time, cached_data = self.cache[cache_key]
                if time.time() - cached_time < self.cache_timeout:
                    return cached_data
            
            # Build search URL
            params = {
                'size': size,
                'page': page - 1,  # API uses 0-based pages
                'sort': f"-{sort}",  # Descending order
                'fields': 'id,name,tag,author,category,rating,downloads,updateDate,premium,price,icon'
            }
            
            if query:
                params['q'] = query
            if category and category != "All":
                params['category'] = self._get_category_id(category)
            
            url = f"{self.BASE_URL}/resources"
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            plugins = []
            
            for item in data:
                try:
                    plugin = PluginInfo(
                        id=str(item.get('id', '')),
                        name=item.get('name', 'Unknown'),
                        tag=item.get('tag', ''),
                        author=item.get('author', {}).get('username', 'Unknown'),
                        description=self._clean_description(item.get('tag', '')),
                        version=self._get_latest_version(item.get('id')),
                        downloads=item.get('downloads', 0),
                        rating=item.get('rating', {}).get('average', 0.0),
                        price=item.get('price', 0.0),
                        category=item.get('category', {}).get('name', 'Unknown'),
                        size="Unknown",
                        updated=self._format_date(item.get('updateDate', 0)),
                        icon_url=item.get('icon', {}).get('url', ''),
                        download_url=f"{self.BASE_URL}/resources/{item.get('id')}/download",
                        premium=item.get('premium', False)
                    )
                    plugins.append(plugin)
                except Exception as e:
                    print(f"Error parsing plugin data: {e}")
                    continue
            
            # Calculate total pages (approximate)
            total_pages = max(1, (len(plugins) // size) + 1) if len(plugins) == size else page
            
            result = (plugins, total_pages)
            self.cache[cache_key] = (time.time(), result)
            return result
            
        except requests.exceptions.RequestException as e:
            print(f"Network error searching plugins: {e}")
            return [], 1
        except Exception as e:
            print(f"Error searching plugins: {e}")
            return [], 1
    
    def get_popular_plugins(self, size: int = 20) -> List[PluginInfo]:
        """Get most popular plugins"""
        plugins, _ = self.search_plugins("", sort="downloads", size=size)
        return plugins
    
    def get_recent_plugins(self, size: int = 20) -> List[PluginInfo]:
        """Get recently updated plugins"""
        plugins, _ = self.search_plugins("", sort="updated", size=size)
        return plugins
    
    def get_categories(self) -> List[str]:
        """Get available plugin categories"""
        try:
            cache_key = "categories"
            if cache_key in self.cache:
                cached_time, cached_data = self.cache[cache_key]
                if time.time() - cached_time < self.cache_timeout * 4:  # Cache longer
                    return cached_data
            
            url = f"{self.BASE_URL}/categories"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            categories = ["All"] + [cat.get('name', 'Unknown') for cat in data if cat.get('name')]
            
            self.cache[cache_key] = (time.time(), categories)
            return categories
            
        except Exception as e:
            print(f"Error fetching categories: {e}")
            return ["All", "General", "Admin Tools", "Mechanics", "Economy", "Fun", "Informational"]
    
    def get_plugin_details(self, plugin_id: str) -> Optional[PluginInfo]:
        """Get detailed information about a specific plugin"""
        try:
            cache_key = f"plugin_{plugin_id}"
            if cache_key in self.cache:
                cached_time, cached_data = self.cache[cache_key]
                if time.time() - cached_time < self.cache_timeout:
                    return cached_data
            
            url = f"{self.BASE_URL}/resources/{plugin_id}"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            item = response.json()
            
            # Get description from separate endpoint
            desc_url = f"{self.BASE_URL}/resources/{plugin_id}/description"
            desc_response = self.session.get(desc_url, timeout=10)
            description = desc_response.text if desc_response.status_code == 200 else item.get('tag', '')
            
            plugin = PluginInfo(
                id=str(item.get('id', '')),
                name=item.get('name', 'Unknown'),
                tag=item.get('tag', ''),
                author=item.get('author', {}).get('username', 'Unknown'),
                description=self._clean_description(description),
                version=self._get_latest_version(plugin_id),
                downloads=item.get('downloads', 0),
                rating=item.get('rating', {}).get('average', 0.0),
                price=item.get('price', 0.0),
                category=item.get('category', {}).get('name', 'Unknown'),
                size="Unknown",
                updated=self._format_date(item.get('updateDate', 0)),
                icon_url=item.get('icon', {}).get('url', ''),
                download_url=f"{self.BASE_URL}/resources/{plugin_id}/download",
                premium=item.get('premium', False)
            )
            
            self.cache[cache_key] = (time.time(), plugin)
            return plugin
            
        except Exception as e:
            print(f"Error getting plugin details: {e}")
            return None
    
    def download_plugin(self, plugin: PluginInfo, destination_path: Path) -> bool:
        """
        Download a plugin to the specified path
        
        Args:
            plugin: Plugin information
            destination_path: Directory to save the plugin
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if plugin.premium:
                print(f"Cannot download premium plugin: {plugin.name}")
                return False
            
            destination_path.mkdir(parents=True, exist_ok=True)
            file_path = destination_path / f"{plugin.name.replace(' ', '_')}.jar"
            
            # Download the plugin
            response = self.session.get(plugin.download_url, timeout=30)
            response.raise_for_status()
            
            # Save to file
            with open(file_path, 'wb') as f:
                f.write(response.content)
            
            print(f"Downloaded plugin: {plugin.name} to {file_path}")
            return True
            
        except requests.exceptions.RequestException as e:
            print(f"Network error downloading plugin {plugin.name}: {e}")
            return False
        except Exception as e:
            print(f"Error downloading plugin {plugin.name}: {e}")
            return False
    
    def _get_category_id(self, category_name: str) -> Optional[str]:
        """Get category ID from name"""
        category_map = {
            "General": "1",
            "Admin Tools": "2", 
            "Informational": "3",
            "Anti-Griefing Tools": "4",
            "Chat Related": "5",
            "Tools and Utilities": "6",
            "Fixes": "7",
            "Mechanics": "8",
            "Economy": "9",
            "Gameplay": "10",
            "Fun": "11",
            "Miscellaneous": "12"
        }
        return category_map.get(category_name)
    
    def _get_latest_version(self, plugin_id: str) -> str:
        """Get the latest version of a plugin"""
        try:
            url = f"{self.BASE_URL}/resources/{plugin_id}/versions/latest"
            response = self.session.get(url, timeout=5)
            if response.status_code == 200:
                version_data = response.json()
                return version_data.get('name', 'Unknown')
        except:
            pass
        return "Unknown"
    
    def _clean_description(self, description: str) -> str:
        """Clean HTML and formatting from description"""
        if not description:
            return "No description available"
        
        # Remove HTML tags
        clean_desc = re.sub(r'<[^>]+>', '', description)
        # Remove extra whitespace
        clean_desc = ' '.join(clean_desc.split())
        # Truncate if too long
        if len(clean_desc) > 200:
            clean_desc = clean_desc[:200] + "..."
        
        return clean_desc or "No description available"
    
    def _format_date(self, timestamp: int) -> str:
        """Format timestamp to readable date"""
        try:
            return time.strftime('%Y-%m-%d', time.localtime(timestamp / 1000))
        except:
            return "Unknown"