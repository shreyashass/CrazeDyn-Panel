# CrazeDyn Panel - Minecraft Server Manager

## Project Overview
A complete Windows desktop application for managing Minecraft servers locally with a modern PyQt6 GUI. Features include auto-download of PaperMC builds, Playit.gg plugin integration, system monitoring, and port forwarding capabilities.

## Recent Changes
- **September 5, 2025**: Complete application implementation
  - Core server management system with background processes
  - Modern dark-themed GUI with server cards and dashboards
  - System monitoring with CPU/RAM tracking and console viewer
  - Port forwarding and network configuration utilities
  - Comprehensive build scripts for Windows deployment
  - Complete test suite for all components

## User Preferences
- Windows-focused desktop application (not web-based)
- Easy to understand interface with visual server status
- Cool, modern dark theme with neon accents
- All-in-one solution with automatic dependency installation
- Support for custom IPs and local hosting

## Project Architecture

### Core Components
- **ServerManager**: Handles server creation, starting/stopping, and monitoring
- **PaperMCDownloader**: Downloads server jars and Playit.gg plugin
- **SystemMonitor**: Tracks CPU, RAM, and network usage
- **PortForwardingManager**: Manages network configuration and port access

### GUI Framework
- **MainWindow**: Primary application interface with tabbed layout
- **ServerCard**: Individual server management widgets
- **CreateServerDialog**: Server creation wizard
- **ModernButton/StatusIndicator**: Custom styled UI components

### Build System
- **setup.bat**: Auto-installs Java, Python, and dependencies
- **build_win.bat**: Creates single executable with PyInstaller
- **build_portable.bat**: Creates portable distribution
- **test_all.bat**: Comprehensive test suite

## Key Features Implemented
1. ✅ Complete server lifecycle management
2. ✅ Real-time system monitoring and console viewing
3. ✅ Automatic PaperMC version fetching and downloading
4. ✅ Playit.gg plugin auto-installation
5. ✅ Port forwarding and firewall configuration
6. ✅ Modern dark UI with animations and status indicators
7. ✅ Multiple build targets (single exe, portable)
8. ✅ Comprehensive dependency management
9. ✅ Full test coverage for core functionality

## File Structure
```
Main/
├── app/                    # Application source code
│   ├── core/              # Server management and downloading
│   ├── gui/               # PyQt6 user interface
│   ├── utils/             # System monitoring and networking
│   └── tests/             # Unit tests
├── servers/               # Created server instances
├── build_scripts/         # Build and test scripts
├── setup.bat             # Dependency installer
├── CDPanel.bat           # Application launcher
└── servers.json          # Server configuration storage
```

## Deployment Notes
- Target platform: Windows 10/11
- Requires Python 3.8+ and PyQt6
- Java 17+ required for Minecraft servers
- Administrator privileges needed for firewall setup
- Designed for local hosting with public access options

## Development Environment
- Built in Replit with cross-platform compatibility
- GUI components may require X server in Linux environments
- Core functionality works across platforms
- Windows-specific features (firewall, UPnP) gracefully degrade on other OS